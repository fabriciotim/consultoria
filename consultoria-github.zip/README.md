# Consultoria Completa de Saúde e Performance

Landing page profissional para divulgação de consultoria integrada de saúde, nutrição e treinamento.

## 🎯 Sobre

Consultoria trimestral (90 dias) com:
- Planos de treinamentos personalizados via app
- Nutrição estratégica
- Avaliação clínica completa
- Suporte 24/7 via WhatsApp

## 💰 Investimento

R$ 1.200,00 (Economia de R$ 2.000,00)

## 📱 Contato

WhatsApp: +55 31 991623223

## 🚀 Como usar

Acesse a página através do GitHub Pages e compartilhe o link em suas redes sociais!

---

Desenvolvido para consultoria profissional de saúde e performance.
